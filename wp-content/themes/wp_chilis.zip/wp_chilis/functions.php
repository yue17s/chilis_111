<?php
/** actiuvamos funciones de WORDSPRESS **/

add_theme_support('post-thumbnails'); /** para poder usar imagenes en WORDPRESS **/
register_nav_menu('header', 'Menu Principal'); /** para ahcer aparecer OPCION MENUS en APARIENCIAS DE WORDPRESS**/

?>