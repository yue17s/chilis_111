<?php
$name='ocrb10';
$type='TTF';
$desc=array (
  'CapHeight' => 710,
  'XHeight' => 534,
  'FontBBox' => '[-87 -335 782 938]',
  'Flags' => 4,
  'Ascent' => 938,
  'Descent' => -335,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 723,
);
$unitsPerEm=1000;
$up=-100;
$ut=50;
$strp=258;
$strs=49;
$ttffile='C:/wamp/www/www/mpdf60/ttfonts/ocrb10.ttf';
$TTCfontID='0';
$originalsize=23112;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='ocrb';
$panose=' 0 0 2 0 5 9 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 800, -200, 0
// usWinAscent/usWinDescent = 938, -335
// hhea Ascent/Descent/LineGap = 938, -335, 90
$useOTL=0x0000;
$rtlPUAstr='';
?>