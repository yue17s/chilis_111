<?php
$name='Sun-ExtB';
$type='TTF';
$desc=array (
  'CapHeight' => 859,
  'XHeight' => 0,
  'FontBBox' => '[-496 -152 1836 1020]',
  'Flags' => 5,
  'Ascent' => 859,
  'Descent' => -141,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$unitsPerEm=256;
$up=-70;
$ut=47;
$strp=254;
$strs=47;
$ttffile='C:/wamp/www/www/mpdf60/ttfonts/Sun-ExtB.ttf';
$TTCfontID='0';
$originalsize=17632200;
$sip=true;
$smp=true;
$BMPselected=false;
$fontkey='sun-extb';
$panose=' 0 0 2 1 6 9 6 1 1 1 1 1';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 859, -141, 141
// usWinAscent/usWinDescent = 859, -141
// hhea Ascent/Descent/LineGap = 859, -141, 141
$useOTL=0x0000;
$rtlPUAstr='';
?>